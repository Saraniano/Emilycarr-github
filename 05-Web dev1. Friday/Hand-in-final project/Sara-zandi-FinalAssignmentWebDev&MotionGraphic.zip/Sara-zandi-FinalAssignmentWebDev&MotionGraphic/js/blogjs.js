	
// bird

// 	$(document).ready(function() {
//    alert('hi');
// });

$(document).ready(function(){
	$(".bird").click(function(){
	    $(this).toggleClass("moved")
	});
})








// $(document).ready(function () {
  
// 	$( "greybird1" ).click(function() {
// 		alert("Hello World"));

// });
// }
